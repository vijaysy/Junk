package com.example.vinay.library;

/**
 * Created by vinay on 6/18/2015.
 */
public class CardNumberFormat {

    public static final int ALL_DIGITS = 0;
    public static final int MASKED_ALL_BUT_LAST_FOUR = 1;
    public static final int ONLY_LAST_FOUR = 2;
    public static final int MASKED_ALL = 3;
}
