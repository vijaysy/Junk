package com.example.vinay.library;

/**
 * Created by vinay on 6/18/2015.
 */
public class CardType {
    public static final int VISA = 0;

    public static final int MASTERCARD = 1;

    public static final int AMERICAN_EXPRESS = 2;

    public static final int DISCOVER = 3;

    public static final int AUTO = 4;
}
